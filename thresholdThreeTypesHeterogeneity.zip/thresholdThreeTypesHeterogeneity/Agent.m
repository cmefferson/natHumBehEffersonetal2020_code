//  Agent.m for simulations of threshold model with heterogeneous preferences, heterogeneous responses to the intervention, and social networks with homophily.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.

#import "Agent.h"
#import "mt19937ar.h"
#import <stdlib.h>
#import <math.h>


@implementation Agent

// getters
-(double) indiffPoint
{
	return indiffPoint;
}

-(double) tempIndiffPoint
{
	return tempIndiffPoint;
}

-(int) initNumCumIndiffPoint
{
	return initNumCumIndiffPoint;
}

-(int) tempInitNumCumIndiffPoint
{
	return tempInitNumCumIndiffPoint;
}

-(int) numInNetwork
{
	return numInNetwork;
}

-(int) lagNumBehOneInNetwork
{
	return lagNumBehOneInNetwork;
}

-(int) targetedByIntervention
{
	return targetedByIntervention;
}

-(double) leftIntRespondsIntervention
{
	return leftIntRespondsIntervention;
}

-(double) rightIntRespondsIntervention
{
	return rightIntRespondsIntervention;
}

-(double) expRespondsIntervention
{
	return expRespondsIntervention;
}

-(int) respondsToIntervention
{
	return respondsToIntervention;
}

-(int) behavior
{
	return behavior;
}

-(int) lagBehavior
{
	return lagBehavior;
}

-(int) changeBehavior
{
	return changeBehavior;
}

// setters 
-(void) setIndiffPoint: (double) indiff
{
	indiffPoint = indiff;
}

-(void) setTempIndiffPoint: (double) tIndiff
{
	tempIndiffPoint = tIndiff;
}

-(void) setInitNumCumIndiffPoint: (int) initNumCumIndiff
{
	initNumCumIndiffPoint = initNumCumIndiff;
}

-(void) setTempInitNumCumIndiffPoint: (int) tInitNumCumIndiff  
{
	tempInitNumCumIndiffPoint = tInitNumCumIndiff;
}

-(void) setNumInNetwork: (int) numNet 
{
	numInNetwork = numNet;
}

-(void) setLagNumBehOneInNetwork: (int) lagNumOne
{
	lagNumBehOneInNetwork = lagNumOne;
}

-(void) setTargetedByIntervention: (int) targ 
{
	targetedByIntervention = targ;
}

-(void) setLeftIntRespondsIntervention: (double) left
{
	leftIntRespondsIntervention = left;
}

-(void) setRightIntRespondsIntervention: (double) right
{
	rightIntRespondsIntervention = right;
}

-(void) setExpRespondsIntervention: (double) exp
{
	expRespondsIntervention = exp;
}

-(void) setBehavior: (int) beh
{
	behavior = beh;
}

-(void) setLagBehavior: (int) lagBeh
{
	lagBehavior = lagBeh;
}

-(void) setChangeBehavior: (int) changeBeh
{
	changeBehavior = changeBeh;
}

// procedural methods
-(void) updateFromTemp
{
	indiffPoint = tempIndiffPoint;
	initNumCumIndiffPoint = tempInitNumCumIndiffPoint;
}

-(double) returnDistanceFromAgent: (Agent *) otherAgent
{
	return fabs(indiffPoint - [otherAgent indiffPoint]);
}

-(void) setRespondsToIntervention
{
	if (targetedByIntervention == 1)
	{
		if (((double) 1.0 - genrand_real2()) <= (leftIntRespondsIntervention + ((rightIntRespondsIntervention - leftIntRespondsIntervention) * pow(indiffPoint,expRespondsIntervention) / (pow(indiffPoint,expRespondsIntervention) + pow((double) 1.0 - indiffPoint,expRespondsIntervention)))))
		{
			respondsToIntervention = 1;
			changeBehavior = 1; // Assumes that all individuals exhibit beh 0 in t = 0 and this method is only called in t = 1
			indiffPoint = 0.0;
			behavior = 1;
		}
		else
		{
			respondsToIntervention = 0;
		}
	}
	else
	{
		respondsToIntervention = 0;
	}
}

-(void) updateBehLagBehChangeBeh
{
	lagBehavior = behavior;
	if ((double) lagNumBehOneInNetwork / (double) numInNetwork < indiffPoint) // Adopt beh 0 if perceived proportion choosing 1 is < indiffPoint; otherwise, adopt beh 1 => consistent with the approach in Granovetter (1978), which assumes people choose beh 1 when indifferent, which is what allows him to work with CDF 
	{
		if (behavior == 1)
		{
			changeBehavior = 1;
		}
		else
		{
			changeBehavior = 0;
		}
		behavior = 0;
	}
	else // Adopt beh 1
	{
		if (behavior == 0)
		{
			changeBehavior = 1;
		}
		else
		{
			changeBehavior = 0;
		}
		behavior = 1;
	}
}

@end