//  Agent.h for simulations of threshold model with heterogeneous preferences, heterogeneous responses to the intervention, and social networks with homophily.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.

#import <Foundation/Foundation.h>

@interface Agent : NSObject {

	double indiffPoint; 		// indifference point for coordinating agent, expressed as proportion of agents choosing beh = 1 such that focal is indifferent; beh = 1 is strictly preferred by focal if proportion above indiffPoint
	double tempIndiffPoint; 	// use when need to update/reorder without overwriting agents before looping through entire population
	int initNumCumIndiffPoint; 		// number of agents with an indifferent point <= focal at t = 0
	int tempInitNumCumIndiffPoint;	// use when need to update/reorder without overwriting agents before looping through entire population

	int numInNetwork;						// number of agents in focal's network
	int lagNumBehOneInNetwork; 				// the number of agents in focal's network exhibiting behavior 1, lag 1

	int targetedByIntervention;				// dummy variable indicating if focal agent targeted by intervention
	double leftIntRespondsIntervention; 	// left intercept for function that controls response to intervention
	double rightIntRespondsIntervention; 	// right intercept for function that controls response to intervention
	double expRespondsIntervention; 		// exponent for function that controls response to intervention
	int respondsToIntervention;				// dummy variable indicating if focal agent responds (i.e. response means agent changes (potentially) threshold and behavior)

	int behavior; 				// behavior, 0 or 1	
	int lagBehavior; 			// behavior, 0 or 1, lag 1
	int changeBehavior; 		// 0 if lagBehavior = behavior, 1 if lagBehavior != behavior
}

// getters
-(double) indiffPoint;
-(double) tempIndiffPoint;
-(int) initNumCumIndiffPoint;
-(int) tempInitNumCumIndiffPoint;
-(int) numInNetwork;
-(int) lagNumBehOneInNetwork;
-(int) targetedByIntervention;
-(double) leftIntRespondsIntervention;
-(double) rightIntRespondsIntervention;
-(double) expRespondsIntervention;
-(int) respondsToIntervention;
-(int) behavior;
-(int) lagBehavior;
-(int) changeBehavior;

// setters
-(void) setIndiffPoint: (double) indiff;
-(void) setTempIndiffPoint: (double) tIndiff;
-(void) setInitNumCumIndiffPoint: (int) initNumCumIndiff;
-(void) setTempInitNumCumIndiffPoint: (int) tInitNumCumIndiff;
-(void) setNumInNetwork: (int) numNet;
-(void) setLagNumBehOneInNetwork: (int) lagNumOne;
-(void) setTargetedByIntervention: (int) targ;
-(void) setLeftIntRespondsIntervention: (double) left;
-(void) setRightIntRespondsIntervention: (double) right;
-(void) setExpRespondsIntervention: (double) exp;
-(void) setBehavior: (int) beh;
-(void) setLagBehavior: (int) lagBeh;
-(void) setChangeBehavior: (int) changeBeh;

// procedural methods
-(void) updateFromTemp;
-(double) returnDistanceFromAgent: (Agent *) otherAgent;
-(void) setRespondsToIntervention;
-(void) updateBehLagBehChangeBeh;

@end