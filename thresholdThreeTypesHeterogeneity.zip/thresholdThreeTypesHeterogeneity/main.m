//  main.m for simulations of threshold model with heterogeneous preferences, heterogeneous responses to the intervention, and social networks with homophily.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.

#import "Agent.h"
#import "mt19937ar.h" // Mersenne twister by Takuji Nishimura and Makoto Matsumoto, readily available.

#import <stdio.h>
#import <stdlib.h>
#import <math.h>
#import <gsl/gsl_rng.h>
#import <gsl/gsl_randist.h>

int main(int argc, const char *argv[])  {

	gsl_rng *gen = gsl_rng_alloc(gsl_rng_mt19937);				// allocate gsl_rng version of Mersenne twister
	
	gsl_rng_set(gen,(unsigned)time(NULL));						// seed gsl_rng version of Mersenne twister
	
	init_genrand((unsigned)time(NULL));						// seed standard Mersenne Twister
	
	// Basic parameters for entire simulation
	int numSims = atoi(argv[1]); // num independent simulations per parameter combination
	int numAgents = atoi(argv[2]); // num agents per simulation, i.e. population size
	
	// Parameters for heterogeneous thresholds (i.e. indiffPoint values)
	double aBetaDist = atof(argv[3]); // first shape parameter for beta distribution that controls distribution of indiffPoint values
	double bBetaDist = atof(argv[4]); // second shape parameter for beta distribution that controls distribution of indiffPoint values

	double leftIntRespondIntervention = atof(argv[5]); // the left intercept of the function that controls heterogeneous responses to intervention
	double rightIntRespondIntervention = atof(argv[6]); // the right intercept of the function that controls heterogeneous responses to intervention
	double expRespondIntervention = atof(argv[7]); // the exponent for the function that controls heterogeneous responses to intervention
	
	// Parameters for social network
	int networkType = atoi(argv[8]); // 1 => random network; 2 => homophilic groups with random links between groups; 3 => link probability that declines as rank distance increases, 4 => link probability that declines as distance increases
	
	// random network
	double probLinkRandNetwork = atof(argv[9]); // the probability a link is formed under a random network (networkType = 1)
	
	// homophilic groups with random links between groups
	double probLinkWithinGroup = atof(argv[10]); // the probability of a within-group link under homophilic groups with random links between groups (networkType = 2)
	double probGroupsAdjacent = atof(argv[11]); // the probability of a between-group link under homophilc groups with random links between groups (networkType = 2)
	double probLinkAdjGroups = atof(argv[12]); // the probability of a link between a pair of nodes in adjacent groups (networkType = 2)
	int numGroups = atoi(argv[13]); // the number of groups under homophilic groups with random links betwen groups (networkType = 2); value should divide numAgents evenly
	int groupSize = numAgents / numGroups;

	// links form as a declining function of rankDistance
	double linkSensitivity = atof(argv[14]); // parameter that controls has fast the probability of forming a link declines as a function of (normalized rank) distance (networkType = 3 | networkType = 4)

	double distanceMatrix[numAgents][numAgents]; // for recording the distance between indiffPoint values for every combination of two agents
	int rankDistanceMatrix[numAgents][numAgents]; // for ranking the distance values with row agent as reference
	int networkMatrix[numAgents][numAgents]; // matrix of dummies for social network; 0 => no link, 1 => link

	// The intervention
	int interventionTarget = atoi(argv[15]); // 1 = target {targetThreshold} agents with lowest value of indifference point; 2 = target randomly; 3 = target {targetThreshold} agents with highest value of indifference point
	int targetThreshold = atoi(argv[16]); // the number of agents to target with intervention	
	
	int tempIndicesAgents[numAgents]; // for randomly selecting agents for the intervention under interventionTarget = 2

	// Various indices and variables to control a given simulation
	int i;	// for indexing
	int j;	// for indexing
	int k;  // for indexing
	int n;	// for indexing
	int s; 	// for indexing
	int t;	// for indexing
	int stopSimulation; // for controlling how long a single simulated population runs
	int countNumAgentsChangeBeh; // for identifying when equilibrium is reached

	// Variables for population dynamics
	double popMeanBeh; 		// for calculating average behavior in population
	double popMeanChangeBeh;	// for calculating average number of agents changing behavior 
	
	// Output files for recording data
	FILE *popData = fopen(argv[17],"w"); // output file for data aggregated at the population level
	fprintf(popData,"sim	gen	meanBehavior    meanChangeBehavior\n");

	// Output files for debugging during development, but perhaps not beyond that
	/* FILE *agentData = fopen("disaggData.txt","w"); // output file for completed disaggregated data
	fprintf(agentData,"sim	gen	agent	indiffPoint	initNumCumIndiffPoint	numInNetwork	lagNumBehOneInNetwork	targetedByIntervention	respondsToIntervention	behavior    lagBehavior changeBehavior\n");
	FILE *indiffPoints = fopen("indiffPoints.txt","w");
	FILE *simpleRanking = fopen("simpleRanking.txt","w");
	FILE *distanceMatrixOut = fopen("distanceMatrix.txt","w");
	FILE *rankMatrixOut = fopen("rankMatrix.txt","w");
	FILE *networkMatrixOut = fopen("networkMatrix.txt","w"); */
	
	// Create population
	Agent *agent[numAgents];
	
	// initialize agents
	for (i = 0; i < numAgents; i++)
	{
		agent[i] = [[Agent alloc] init];
	}
	
	// loop over sims
	for (s = 0; s < numSims; s++)
	{
		// loop over agents to initialize various quantities
		for (i = 0; i < numAgents; i++)
		{
			[agent[i] setIndiffPoint: gsl_ran_beta(gen,aBetaDist,bBetaDist)];
			[agent[i] setNumInNetwork: 0];
			[agent[i] setLagNumBehOneInNetwork: -99];
			[agent[i] setTargetedByIntervention: 0];
			[agent[i] setLeftIntRespondsIntervention: leftIntRespondIntervention];
			[agent[i] setRightIntRespondsIntervention: rightIntRespondIntervention];
			[agent[i] setExpRespondsIntervention: expRespondIntervention];
			[agent[i] setBehavior: 0]; // The entire population begins with beh = 0.  For policy illustration, think of this as a harmful behavior.
            [agent[i] setLagBehavior: -99];
            [agent[i] setChangeBehavior: 0];
            for (j = 0; j < numAgents; j++)
            {
            	distanceMatrix[i][j] = -99.0;
            	rankDistanceMatrix[i][j] = -99;
            	networkMatrix[i][j] = -99;
            }
		}

		/* Find i's place in the initial cumulative distribution of indifference points, from lowest (1) to highest (numAgents).
		Simulations are based on the prop of agents choosing 1.  Thus, an indifference point near 0 means the agent values beh 1, while an indifference point near 1 means the agent values beh 0.
		B/c this is the cumulative distribution function, which starts at 1, => need to subtract 1 when using the agents' values for indexing. */
		for (i = 0; i < numAgents; i++)
		{
			[agent[i] setInitNumCumIndiffPoint: 0];
		 
			for (j = 0; j < numAgents; j++)
			{
				if ([agent[j] indiffPoint] <= [agent[i] indiffPoint])
				{
					[agent[i] setInitNumCumIndiffPoint: ([agent[i] initNumCumIndiffPoint] + 1)];
				}
			}
		}

		// Print to file to see if it's working right
		/* for (i = 0; i < numAgents; i++)
		{
			if (i < numAgents - 1)
			{
				fprintf(indiffPoints,"%f	", [agent[i] indiffPoint]);
				fprintf(simpleRanking,"%i	", [agent[i] initNumCumIndiffPoint]);
			}
			else
			{
				fprintf(indiffPoints,"%f\n", [agent[i] indiffPoint]);
				fprintf(simpleRanking,"%i\n", [agent[i] initNumCumIndiffPoint]);
			}
		} */

		// Reorder agents from most amenable to behavior change to least amenable
		for (i = 0; i < numAgents; i++)
		{
			[agent[[agent[i] initNumCumIndiffPoint] - 1] setTempIndiffPoint: [agent[i] indiffPoint]]; 
			[agent[[agent[i] initNumCumIndiffPoint] - 1] setTempInitNumCumIndiffPoint: [agent[i] initNumCumIndiffPoint]];
		}

		// Continue with reordering
		for (i = 0; i < numAgents; i++)
		{
			[agent[i] updateFromTemp];
		}

		// Print to file to see if it's working right
		/* for (i = 0; i < numAgents; i++)
		{
			if (i < numAgents - 1)
			{
				fprintf(indiffPoints,"%f	", [agent[i] indiffPoint]);
				fprintf(simpleRanking,"%i	", [agent[i] initNumCumIndiffPoint]);
			}
			else
			{
				fprintf(indiffPoints,"%f\n", [agent[i] indiffPoint]);
				fprintf(simpleRanking,"%i\n", [agent[i] initNumCumIndiffPoint]);
			}
		} */

		// loop over agents to determine the similarity between every pair, before the intervention, and by extension the social network of each agent, which is in some cases based on homophily
		for (i = 0; i < numAgents; i++)
		{
			for (j = 0; j < numAgents; j++) // calculate distances with distance to self as 0.0
			{
				distanceMatrix[i][j] = 0.0;
				if (i != j)
				{
					distanceMatrix[i][j] = [agent[i] returnDistanceFromAgent: agent[j]];
				}
			}
			for (j = 0; j < numAgents; j++) // calculate rank of distances with row agent as a reference; self is given a rank of 0
			{
				rankDistanceMatrix[i][j] = 0;
				for (k = 0; k < numAgents; k++)
				{
					if (distanceMatrix[i][k] < distanceMatrix[i][j])
					{
						rankDistanceMatrix[i][j]++;
					}
				}
			}
		}

		// form network
		if (networkType == 1) // random network
		{
			for (i = 0; i < numAgents; i++)
			{
				for (j = i; j < numAgents; j++)
				{
					if (i == j)
					{
						networkMatrix[i][j] = 1;
					}
					else
					{
						if ((double) 1.0 - genrand_real2() <= probLinkRandNetwork) // link formed
						{
							networkMatrix[i][j] = 1;
							networkMatrix[j][i] = 1;
						}
						else
						{
							networkMatrix[i][j] = 0;
							networkMatrix[j][i] = 0;
						}
					}
				}
			}
		}
		else if (networkType == 2) // groups with random links between agents within groups and random links between groups
		{
			for (k = 0; k < numGroups; k++)
			{
				for (i = k * groupSize; i < (k + 1) * groupSize; i++)  // within groups
				{
					for (j = k * groupSize; j < (k + 1) * groupSize; j++)
					{
						if (i == j) // link with self
						{
							networkMatrix[i][j] = 1;
						}
						else // within group, but not self
						{
							if ((double) 1.0 - genrand_real2() <= probLinkWithinGroup) // within-group link formed
							{
								networkMatrix[i][j] = 1;
								networkMatrix[j][i] = 1;
							}
							else
							{
								networkMatrix[i][j] = 0;
								networkMatrix[j][i] = 0;
							}
						}
					}
				}
				if (k < (numGroups - 1)) // between groups
				{
					for (n = k + 1; n < numGroups; n++)
					{						
						if ((double) 1.0 - genrand_real2() <= probGroupsAdjacent) // groups adjacent
						{
							for (i = k * groupSize; i < (k + 1) * groupSize; i++)
							{
								for (j = n * groupSize; j < (n + 1) * groupSize; j++)
								{
									if ((double) 1.0 - genrand_real2() <= probLinkAdjGroups) // link formed
									{
										networkMatrix[i][j] = 1;
										networkMatrix[j][i] = 1;
									}
									else // link not formed
									{
										networkMatrix[i][j] = 0;
										networkMatrix[j][i] = 0;
									}
								}
							}
						}
						else // groups not adjacent
						{
							for (i = k * groupSize; i < (k + 1) * groupSize; i++)
							{
								for (j = n * groupSize; j < (n + 1) * groupSize; j++)
								{
									networkMatrix[i][j] = 0;
									networkMatrix[j][i] = 0;
								}
							}

						}
					}
				}
			}
		}
		// IMPORTANTLY, the matrix of rank distances is not necessarily symmetric, i.e. the rank distance from i to j is not necessarily the same as from j to i. 
		// For this reason, it doesn't make sense to specify a matrix of links by focusing only either the upper or lower triangle of networkMatrix.
		// Put differently, it doesn't make sense to create undirected edges.
		// => For this algorithm, directed edges are assigned, with the row agent as focal, based on rank distances between the row agent and every column agent.
		else if (networkType == 3) // random links with probabilities that decline as a function of normalized rank distance from focal agent
		{
			for (i = 0; i < numAgents; i++)
			{
				for (j = 0; j < numAgents; j++)
				{
					if ((double) 1.0 - genrand_real2() <= exp(-linkSensitivity * ((double) rankDistanceMatrix[i][j] / (double) (numAgents-1)))) // directed link formed in which i will pay attention to j
					{
						networkMatrix[i][j] = 1;
					}
					else
					{
						networkMatrix[i][j] = 0;
					}
				}
			}
		}
		else if (networkType == 4) // random links with probabilities that decline as a function of distance from focal agent
		{
			for (i = 0; i < numAgents; i++)
			{
				for (j = i; j < numAgents; j++)
				{
					if ((double) 1.0 - genrand_real2() <= exp(-linkSensitivity * distanceMatrix[i][j])) // link formed
					{
						networkMatrix[i][j] = 1;
						networkMatrix[j][i] = 1;
					}
					else
					{
						networkMatrix[i][j] = 0;
						networkMatrix[j][i] = 0;
					}
				}
			}
		}
		else
		{
			printf("Problem with networkType.\n");
		}

		// calculate number in network for each agent; value of numInNetwork initialized to 0 at beginning of each simulation
		for (i = 0; i < numAgents; i++)
		{
			for (j = 0; j < numAgents; j++)
			{
				[agent[i] setNumInNetwork: [agent[i] numInNetwork] + networkMatrix[i][j]];
			}
		}

		// print matrices for debugging purposes
		/* for (i = 0; i < numAgents; i++)
		{
			for (j = 0; j < numAgents; j++)
			{
				if (j < (numAgents - 1))
				{
					fprintf(distanceMatrixOut,"%f	", distanceMatrix[i][j]);
					fprintf(rankMatrixOut,"%i	", rankDistanceMatrix[i][j]);
					fprintf(networkMatrixOut,"%i	", networkMatrix[i][j]);
				}
				else
				{
					fprintf(distanceMatrixOut,"%f\n", distanceMatrix[i][j]);
					fprintf(rankMatrixOut,"%i\n", rankDistanceMatrix[i][j]);
					fprintf(networkMatrixOut,"%i\n", networkMatrix[i][j]);
				}
			}
		} */
		
		// initialize tempIndicesAgents for randomly selecting agents in sim s
		for (i = 0; i < numAgents; i++)
		{
			tempIndicesAgents[i] = i;
		}
		
		// loop over gens => dynamics for each simulation begin here
		t = 0;
		stopSimulation = 0;
		while (stopSimulation == 0)
		{			
			if (t == 1) // the period in which the exogenous intervention occurs
			{
				// set lag behavior and lagNumBehOneInNetwork; note that behavior has not been updated yet in t = 1, and so lagBehavior is simply behavior
				for (i = 0; i < numAgents; i++)
				{
					[agent[i] setLagBehavior: [agent[i] behavior]];
					[agent[i] setLagNumBehOneInNetwork: 0];
					for (j = 0; j < numAgents; j++)
					{
						if (networkMatrix[i][j] == 1)
						{
							[agent[i] setLagNumBehOneInNetwork: [agent[i] lagNumBehOneInNetwork] + [agent[j] behavior]];
						}
					}
				}

				// implement intervention => exogenous behavior change for interventionTarget agents
				if (interventionTarget == 1) // target {targetThreshold} lowest values of indifference point, i.e. those most amenable to change
				{
					for (i = 0; i < targetThreshold; i++)
					{
						[agent[i] setTargetedByIntervention: 1];
						[agent[i] setRespondsToIntervention];
					}
				}
				else if (interventionTarget == 2) // target {targetThreshold} randomly selected agents
				{
					// shuffle agents
					gsl_ran_shuffle(gen,tempIndicesAgents,numAgents,sizeof(int));
					
					// target the randomly selected agents for behavior change
					for (i = 0; i < targetThreshold; i++)
					{
						[agent[tempIndicesAgents[i]] setTargetedByIntervention: 1];
						[agent[tempIndicesAgents[i]] setRespondsToIntervention];
					}
				}
				else if (interventionTarget == 3) // target {targetThreshold} highest values of indifference point, i.e. those most resistant to change
				{
					for (i = (numAgents - targetThreshold); i < numAgents; i++)
					{
						[agent[i] setTargetedByIntervention: 1];
						[agent[i] setRespondsToIntervention];
					}
				}
				else
				{
					printf("Problem with interventionTarget.\n");
				}
			} // close t = 1 
			
			if (t > 1) // endogenous cultural evolutionary dynamics in periods that follow the period with the intervention
			{
				// set lagNumBehOneInNetwork; note that behavior has not been updated yet in t, and so lagBehavior is simply behavior
				for (i = 0; i < numAgents; i++) // identify number of others in focal's network exhibiting beh 1 for lag 1
				{
					[agent[i] setLagNumBehOneInNetwork: 0];
					for (j = 0; j < numAgents; j++)
					{
						if (networkMatrix[i][j] == 1)
						{
							[agent[i] setLagNumBehOneInNetwork: ([agent[i] lagNumBehOneInNetwork] + [agent[j] behavior])];
						}
					}
				}
				
				for (i = 0; i < numAgents; i++) // update behavior, lag behavior, change behavior
				{
					[agent[i] updateBehLagBehChangeBeh];
				}					
			} // close t > 1

			if (t >= 1) // check to see if should stop simulation
			{
				countNumAgentsChangeBeh = 0; // check to see if should stop simulation
				for (i = 0; i < numAgents; i++)
				{
					countNumAgentsChangeBeh += [agent[i] changeBehavior];
				}
				if (countNumAgentsChangeBeh == 0)
				{
					stopSimulation = 1;
					
					// Calculate and record population dynamics
					popMeanBeh = 0.0;
					popMeanChangeBeh = 0.0;
					for (i = 0; i < numAgents; i++)
					{
						// Calculate population averages
						popMeanBeh += (double) [agent[i] behavior];
						popMeanChangeBeh += (double) [agent[i] changeBehavior];
					} // close loop over agents 
					popMeanBeh /= (double) numAgents;
					popMeanChangeBeh /= (double) numAgents;
			
					fprintf(popData,"%i	%i	%f	%f\n", s, t, popMeanBeh, popMeanChangeBeh); 
				} // close stop simulation condition, which includes printing data			
			} // close t >= 1
				
			t++; // update gen index for while loop
		
		} // close loop over gens
	} // close loop over sims
	 
	// release agents
	for (i = 0; i < numAgents; i++)
	{
		[agent[i] release];
	}
	
	// int fclose(FILE *agentData);
	int fclose(FILE *popData);
	/* int fclose(FILE *indiffPoints);
	int fclose(FILE *simpleRanking);
	int fclose(FILE *distanceMatrixOut);
	int fclose(FILE *rankMatrixOut);
	int fclose(FILE *networkMatrixOut); */
	
	gsl_rng_free(gen);

	return 0;
	
}