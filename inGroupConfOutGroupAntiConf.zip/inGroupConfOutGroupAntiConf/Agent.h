//  Agent.h for simulations in applied cultural evolution based on freq-dep social learning in a structured population.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.

#import <Foundation/Foundation.h>

@interface Agent : NSObject {

	double leftIntIn; 				// the left intercept of the freq-dep social learning function, in-group soc learning
	double rightIntIn;				// the right intercept of the freq-dep social learning function, in-group soc learning
	double expIn;					// the exponent on the social learning function, in-group soc learning
	
	double leftIntOut; 				// the left intercept of the freq-dep social learning function, out-group soc learning
	double rightIntOut;				// the right intercept of the freq-dep social learning function, out-group soc learning
	double expOut;					// the exponent on the social learning function, out-group soc learning
	
	double weightSocLearningIn;		// the probability of in-group soc learning as opposed to out-group soc learning
	
	double propAtOrBelowDiagIn;			// the net preference measure for beh = 1, i.e. measure of soc learning function at or below diagonal, in-group soc learning
	double propAtOrBelowDiagOut;		// the net preference measure for beh = 1, i.e. measure of soc learning function at or below diagonal, out-group soc learning
	double propAtOrBelowDiagWeighted;	// the net preference measure for beh = 1, i.e. measure of soc learning function at or below diagonal, weighted soc learning function
	
	int numCumPropAtOrBelowDiagWeighted;	// the cumulative number of agents with a value of propAtOrBelowDiag at or below value for focal agent, weighted function
	
	int behavior; 					// behavior, 0 or 1	
	int lagBehavior; 				// behavior, 0 or 1, lag 1
	int changeBehavior; 			// 0 if lagBehavior != behavior, 1 otherwise
	
	int socLearningIn;				// dummy recording if soc learning was w.r.t. in-group reference or out-group reference
}

// getters
-(double) leftIntIn;
-(double) rightIntIn;
-(double) expIn;
-(double) leftIntOut;
-(double) rightIntOut;
-(double) expOut;
-(double) weightSocLearningIn;
-(double) propAtOrBelowDiagIn;
-(double) propAtOrBelowDiagOut;
-(double) propAtOrBelowDiagWeighted;
-(int) numCumPropAtOrBelowDiagWeighted;
-(int) behavior;
-(int) lagBehavior;
-(int) changeBehavior;
-(int) socLearningIn;

// setters
-(void) setLeftIntIn: (double) left_int_in;
-(void) setRightIntIn: (double) right_int_in;
-(void) setExpIn: (double) exponent_in;
-(void) setLeftIntOut: (double) left_int_out;
-(void) setRightIntOut: (double) right_int_out;
-(void) setExpOut: (double) exponent_out;
-(void) setWeightSocLearningIn: (double) wIn;
-(void) setPropAtOrBelowDiagIn: (double) propAtOrBelowIn;
-(void) setPropAtOrBelowDiagOut: (double) propAtOrBelowOut;
-(void) setPropAtOrBelowDiagWeighted: (double) propAtOrBelowWeighted;
-(void) setNumCumPropAtOrBelowDiagWeighted: (int) numCumPropWeighted;
-(void) setBehavior: (int) beh;
-(void) setLagBehavior: (int) lagBeh;
-(void) setChangeBehavior: (int) changeBeh;
-(void) setSocLearningIn: (int) socLearnIn;

// procedural methods
-(void) calcPropAtOrBelowDiagIn;
-(void) calcPropAtOrBelowDiagOut;
-(void) calcPropAtOrBelowDiagWeighted;
-(void) freqDepSocLearningWithIn: (double) freqBehOneIn andOut: (double) freqBehOneOut;

@end