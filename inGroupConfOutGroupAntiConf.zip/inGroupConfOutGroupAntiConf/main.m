//  main.m for simulations in applied cultural evolution based on freq-dep social learning.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.


#import "Agent.h"
#import "mt19937ar.h" // Mersenne twister by Takuji Nishimura and Makoto Matsumoto, readily available.

#import <stdio.h>
#import <stdlib.h>
#import <gsl/gsl_rng.h>
#import <gsl/gsl_randist.h>

int main(int argc, const char *argv[])  {

	gsl_rng *gen = gsl_rng_alloc(gsl_rng_mt19937);				// allocate gsl_rng version of Mersenne twister
	
	gsl_rng_set(gen,(unsigned)time(NULL));						// seed gsl_rng version of Mersenne twister
	
	init_genrand((unsigned)time(NULL));							// seed standard Mersenne Twister
	
	// Needed parameters for simulations
	
	int numSims = atoi(argv[1]); // num independent simulations per parameter combination
	
	int numTimeSteps = atoi(argv[2]); // num time steps per simulation
	
	int numAgentsPerGroup = atoi(argv[3]); // num agents per group per simulation
	
	int numGroups = 2;				// assume a simple structured pop with only two groups
	
	double aBetaDistLeftIn = atof(argv[4]); // first shape parameter for beta distribution, left intercept, in-group
	
	double bBetaDistLeftIn = atof(argv[5]); // second shape parameter for beta distribution, left intercept, in-group
	
	double aBetaDistRightIn = atof(argv[6]); // first shape parameter for beta distribution, right intercept, in-group
	
	double bBetaDistRightIn = atof(argv[7]); // second shape parameter for beta distribution, right intercept, in-group
	
	double aBetaDistExpIn = atof(argv[8]); // first shape parameter for beta distribution, exponent on soc learning function, in-group
	
	double bBetaDistExpIn = atof(argv[9]); // second shape parameter for beta distribution, exponent on soc learning function, in-group	
	
	double stretchExpIn = atof(argv[10]); // multiplication factor for stretching the support of the dist for exp values, in-group
	
	double aBetaDistLeftOut = atof(argv[11]); // first shape parameter for beta distribution, left intercept, out-group
	
	double bBetaDistLeftOut = atof(argv[12]); // second shape parameter for beta distribution, left intercept, out-group
	
	double aBetaDistRightOut = atof(argv[13]); // first shape parameter for beta distribution, right intercept, out-group
	
	double bBetaDistRightOut = atof(argv[14]); // second shape parameter for beta distribution, right intercept, out-group
	
	double aBetaDistExpOut = atof(argv[15]); // first shape parameter for beta distribution, exponent on soc learning function, out-group
	
	double bBetaDistExpOut = atof(argv[16]); // second shape parameter for beta distribution, exponent on soc learning function, out-group	
	
	double stretchExpOut = atof(argv[17]); // multiplication factor for stretching the support of the dist for exp values, in-group
	
	int interventionTarget = atoi(argv[18]); // 1 = target {targetThreshold} agents with lowest value of propAtOrBelowDiagWeighted (receptive to change); 2 = target randomly; 3 = target {targetThreshold} agents with highest value of propAtOrBelowDiagWeighted (resistant to change)
	
	int targetThreshold = atoi(argv[19]); // the number of values of propAtOrBelowDiagWeighted to target
	
	double wgtSocLearningIn = atof(argv[20]); // the common prob that an agent learns socially w.r.t. the in-group
	
	int g; 	// for indexing	
	int i;	// for indexing
	int j;	// for indexing
	int k; 	// for indexing
	int s; 	// for indexing
	int t;	// for indexing
	
	int intervention;	// dummy that records the period in which the intervention occurs
	
	int tempIndicesAgents[numGroups * numAgentsPerGroup]; // for randomly selecting agents, population level
	
	double popMeanBehGroupZero; 		// for calculating average behavior in group 0
	double popMeanLagBehGroupZero;		// for calculating average behavior in group 0 for lag 1
	double popMeanChangeBehGroupZero;	// for calculating average number of agents changing behavior in group 0
	
	double popMeanBehGroupOne; 			// for calculating average behavior in group 1
	double popMeanLagBehGroupOne;		// for calculating average behavior in group 1 for lag 1
	double popMeanChangeBehGroupOne;	// for calculating average number of agents changing behavior in group 1
	
	double popMeanBeh; 		// for calculating average behavior in population
	double popMeanChangeBeh;	// for calculating average number of agents changing behavior 
	
	/* FILE *agentData = fopen(argv[21],"w"); // output file for completely disaggregated data
	fprintf(agentData,"sim	gen	group	agent	leftIntIn	rightIntIn	expIn	leftIntOut	rightIntOut	expOut	propAtOrBelowDiagIn	propAtOrBelowDiagOut	propAtOrBelowDiagWeighted	numCumPropAtOrBelowDiagWeighted	behavior	lagBehavior	changeBehavior	socLearningIn\n"); */
	
	FILE *popData = fopen(argv[21],"w"); // output file for data aggregated at the population level
	fprintf(popData,"sim	gen	meanBehaviorGroupZero	meanChangeBehaviorGroupZero	meanBehaviorGroupOne	meanChangeBehaviorGroupOne	meanBehavior	meanChangeBehavior	intervention\n");
	
	Agent *agent[numGroups][numAgentsPerGroup];
	
	for (g = 0; g < numGroups; g++)
	{
		for (i = 0; i < numAgentsPerGroup; i++)
		{
			agent[g][i] = [[Agent alloc] init];
		}
	}
	
	// loop over sims
	for (s = 0; s < numSims; s++)
	{
		// loop over groups, then agents
		for (g = 0; g < numGroups; g++)
		{
			for (i = 0; i < numAgentsPerGroup; i++)
			{
				[agent[g][i] setLeftIntIn: gsl_ran_beta(gen,aBetaDistLeftIn,bBetaDistLeftIn)];
				[agent[g][i] setRightIntIn: gsl_ran_beta(gen,aBetaDistRightIn,bBetaDistRightIn)];
				[agent[g][i] setExpIn: (stretchExpIn * gsl_ran_beta(gen,aBetaDistExpIn,bBetaDistExpIn))];
				[agent[g][i] setLeftIntOut: gsl_ran_beta(gen,aBetaDistLeftOut,bBetaDistLeftOut)];
				[agent[g][i] setRightIntOut: gsl_ran_beta(gen,aBetaDistRightOut,bBetaDistRightOut)];
				[agent[g][i] setExpOut: (stretchExpOut * gsl_ran_beta(gen,aBetaDistExpOut,bBetaDistExpOut))];
				[agent[g][i] setWeightSocLearningIn: wgtSocLearningIn];
				[agent[g][i] calcPropAtOrBelowDiagIn];
				[agent[g][i] calcPropAtOrBelowDiagOut];
				[agent[g][i] calcPropAtOrBelowDiagWeighted];
				[agent[g][i] setBehavior: 0]; // The entire population begins with beh = 0.  For policy illustration, think of this as a harmful behavior.
           	 	[agent[g][i] setLagBehavior: -99];
            	[agent[g][i] setChangeBehavior: -99];
			}
		}
		
		// initialize tempIndicesAgents for randomly selecting agents in sim s
		for (i = 0; i < (numGroups * numAgentsPerGroup); i++)
		{
			tempIndicesAgents[i] = i;
		}
	
		// Find rank of i's propAtOrBelowDiag, from lowest (1) to highest (numGroups * numAgentsPerGroup).
		// Simulations are based on the prop of agents choosing 1.
		// Thus, a value near 0 means the agent values beh 1 as much of the social learning function is above the diagonal.
		// A value near 1, in contrast, means the agent values beh 0 as much of the social learning function is at or below the diagonal.
		// Put differently, values near 0 are for agents amenable to behavior change, while values near 1 are for agents resistant to behavior change.
		for (g = 0; g < numGroups; g++)
		{
			for (i = 0; i < numAgentsPerGroup; i++)
			{
				[agent[g][i] setNumCumPropAtOrBelowDiagWeighted: 0];
		 
		 		for (k = 0; k < numGroups; k++)
		 		{
					for (j = 0; j < numAgentsPerGroup; j++)
					{
						if ([agent[k][j] propAtOrBelowDiagWeighted] <= [agent[g][i] propAtOrBelowDiagWeighted])
						{
							[agent[g][i] setNumCumPropAtOrBelowDiagWeighted: ([agent[g][i] numCumPropAtOrBelowDiagWeighted] + 1)];
						}
					}
				}
			}
		}
	
		// loop over gens
		for (t = 0; t < numTimeSteps; t++)
		{			
			// set lag behavior
			if (t > 0)
			{
				for (g = 0; g < numGroups; g++)
				{
					for (i = 0; i < numAgentsPerGroup; i++)
					{
						[agent[g][i] setLagBehavior: [agent[g][i] behavior]];
					}
				}
			}
			
			// initialize intervention dummy
			intervention = 0;
			
			// implement limited behavior change for interventionTarget agents
			if (t == (numTimeSteps / 2))
			{
				// set intervention dummy
				intervention = 1;
				
				if (interventionTarget == 1) // target {targetThreshold} lowest values of propAtOrBelowDiagWeighted, i.e. those most amenable to change
				{
					for (g = 0; g < numGroups; g++)
					{
						for (i = 0; i < numAgentsPerGroup; i++)
						{
							if ([agent[g][i] numCumPropAtOrBelowDiagWeighted] <= targetThreshold)
							{
								[agent[g][i] setBehavior: 1]; // The targeted agent chooses beh = 1.
								[agent[g][i] setLeftIntIn: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
								[agent[g][i] setRightIntIn: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
								[agent[g][i] setLeftIntOut: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
								[agent[g][i] setRightIntOut: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
							}
						}
					}
				}
				else if (interventionTarget == 2) // target {targetThreshold} randomly selected agents
				{
					// shuffle agents
					gsl_ran_shuffle(gen,tempIndicesAgents,numGroups * numAgentsPerGroup,sizeof(int));
					
					// target the randomly selected agents for behavior change
					for (i = 0; i < targetThreshold; i++)
					{
						[agent[tempIndicesAgents[i] / numAgentsPerGroup][tempIndicesAgents[i] % numAgentsPerGroup] setBehavior: 1]; // The targeted agent chooses beh = 1.
						[agent[tempIndicesAgents[i] / numAgentsPerGroup][tempIndicesAgents[i] % numAgentsPerGroup] setLeftIntIn: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
						[agent[tempIndicesAgents[i] / numAgentsPerGroup][tempIndicesAgents[i] % numAgentsPerGroup] setRightIntIn: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
						[agent[tempIndicesAgents[i] / numAgentsPerGroup][tempIndicesAgents[i] % numAgentsPerGroup] setLeftIntOut: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
						[agent[tempIndicesAgents[i] / numAgentsPerGroup][tempIndicesAgents[i] % numAgentsPerGroup] setRightIntOut: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
					}
				}
				else if (interventionTarget == 3) // target {targetThreshold} highest values of propAtOrBelowDiagWeighted, i.e. those most resistant to change
				{
					for (g = 0; g < numGroups; g++)
					{
						for (i = 0; i < numAgentsPerGroup; i++)
						{
							if ([agent[g][i] numCumPropAtOrBelowDiagWeighted] > (numGroups * numAgentsPerGroup - targetThreshold))
							{
								[agent[g][i] setBehavior: 1]; // The targeted agent chooses beh = 1.
								[agent[g][i] setLeftIntIn: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
								[agent[g][i] setRightIntIn: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
								[agent[g][i] setLeftIntOut: 1.0]; // The targeted agent will choose beh = 1 with probability 1 in the future.
								[agent[g][i] setRightIntOut: 1.0]; // The targeted agent will chose beh = 1 with probability 1 in the future.
							}
						}
					}
				}
				else
				{
					printf("Problem with interventionTarget.\n");
				}
				
				// set behavior change
				for (g = 0; g < numGroups; g++)
				{
					for (i = 0; i < numAgentsPerGroup; i++)
					{
						if ([agent[g][i] behavior] == [agent[g][i] lagBehavior]) // set changeBehavior
						{
							[agent[g][i] setChangeBehavior: 0];
						}
						else
						{
							[agent[g][i] setChangeBehavior: 1];
						}
					}
				}
			} // close condition t == numTimeSteps / 2, i.e. gen for intervention
			
			if (t > 0) // implement endogenous cultural evolutionary dynamics except for the period with the limited intervention
			{
				popMeanLagBehGroupZero = 0.0;
				popMeanLagBehGroupOne = 0.0;
				
				for (i = 0; i < numAgentsPerGroup; i++)
				{
					popMeanLagBehGroupZero += (double) [agent[0][i] lagBehavior];
					popMeanLagBehGroupOne += (double) [agent[1][i] lagBehavior];
				}
				
				popMeanLagBehGroupZero /= (double) numAgentsPerGroup;
				popMeanLagBehGroupOne /= (double) numAgentsPerGroup;
				
				
				if (intervention == 0) // only implement endogenous cult evo if no intervention
				{
					for (i = 0; i < numAgentsPerGroup; i++)
					{
						[agent[0][i] freqDepSocLearningWithIn: popMeanLagBehGroupZero andOut: popMeanLagBehGroupOne]; // update behavior
						[agent[1][i] freqDepSocLearningWithIn: popMeanLagBehGroupOne andOut: popMeanLagBehGroupZero]; // update behavior
					}
					
					for (g = 0; g < numGroups; g++)
					{
						for (i = 0; i < numAgentsPerGroup; i++)
						{
							if ([agent[g][i] behavior] == [agent[g][i] lagBehavior]) // set changeBehavior
							{
								[agent[g][i] setChangeBehavior: 0];
							}
							else
							{
								[agent[g][i] setChangeBehavior: 1];
							}
						} // close loop over agents
					} // close loop over groups
				} // close intervention == 0
			} // close t > 0
				
			// Calculate and record population dynamics
			popMeanBehGroupZero = 0.0;
			popMeanChangeBehGroupZero = 0.0;
			popMeanBehGroupOne = 0.0;
			popMeanChangeBehGroupOne = 0.0;
			popMeanBeh = 0.0;
			popMeanChangeBeh = 0.0;
			
			for (g = 0; g < numGroups; g++)
			{
				for (i = 0; i < numAgentsPerGroup; i++)
				{
					// Print
					// fprintf(agentData,"%i	%i	%i	%i	%f	%f	%f	%f	%f	%f	%f	%f	%f	%i	%i	%i	%i	%i\n", s, t, g, i, [agent[g][i] leftIntIn], [agent[g][i] rightIntIn], [agent[g][i] expIn], [agent[g][i] leftIntOut], [agent[g][i] rightIntOut], [agent[g][i] expOut], [agent[g][i] propAtOrBelowDiagIn], [agent[g][i] propAtOrBelowDiagOut], [agent[g][i] propAtOrBelowDiagWeighted], [agent[g][i] numCumPropAtOrBelowDiagWeighted], [agent[g][i] behavior], [agent[g][i] lagBehavior], [agent[g][i] changeBehavior], [agent[g][i] socLearningIn]);
				
					// Calculate averages
					if (g == 0)
					{
						popMeanBehGroupZero += (double) [agent[g][i] behavior];
						popMeanChangeBehGroupZero += (double) [agent[g][i] changeBehavior];
					}
					if (g == 1)
					{
						popMeanBehGroupOne += (double) [agent[g][i] behavior];
						popMeanChangeBehGroupOne += (double) [agent[g][i] changeBehavior];
					}						
					
					popMeanBeh += (double) [agent[g][i] behavior];
					popMeanChangeBeh += (double) [agent[g][i] changeBehavior];
				} // close loop over agents	
			} // close loop over groups
			
			popMeanBehGroupZero /= (double) numAgentsPerGroup;
			popMeanChangeBehGroupZero /= (double) numAgentsPerGroup;
			
			popMeanBehGroupOne /= (double) numAgentsPerGroup;
			popMeanChangeBehGroupOne /= (double) numAgentsPerGroup;
			
			popMeanBeh /= ((double) numGroups * (double) numAgentsPerGroup);
			popMeanChangeBeh /= ((double) numGroups * (double) numAgentsPerGroup);
			
			fprintf(popData,"%i	%i	%f	%f	%f	%f	%f	%f	%i\n", s, t, popMeanBehGroupZero, popMeanChangeBehGroupZero, popMeanBehGroupOne, popMeanChangeBehGroupOne, popMeanBeh, popMeanChangeBeh, intervention); 
			
		} // close loop over gens
	} // close loop over sims
	 
	// release agents
	for (g = 0; g < numGroups; g++)
	{
		for (i = 0; i < numAgentsPerGroup; i++)
		{
			[agent[g][i] release];
		}
	}
	
	// int fclose(FILE *agentData);
	int fclose(FILE *popData);
	
	gsl_rng_free(gen);

	return 0;
	
}