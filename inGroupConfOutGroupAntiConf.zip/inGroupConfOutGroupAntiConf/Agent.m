//  Agent.m for simulations in applied cultural evolution based on freq-dep social learning in a structured population.
//  
//  Created by Charles Efferson.
//  Copyright 2019, Charles Efferson.  
//  All rights reserved.

#import "Agent.h"
#import "mt19937ar.h"
#import <stdlib.h>


@implementation Agent

// getters
-(double) leftIntIn
{
	return leftIntIn;
}

-(double) rightIntIn
{
	return rightIntIn;
}

-(double) expIn
{
	return expIn;
}

-(double) leftIntOut
{
	return leftIntOut;
}

-(double) rightIntOut
{
	return rightIntOut;
}

-(double) expOut
{
	return expOut;
}

-(double) weightSocLearningIn
{
	return weightSocLearningIn;
}

-(double) propAtOrBelowDiagIn
{
	return propAtOrBelowDiagIn;
}

-(double) propAtOrBelowDiagOut
{
	return propAtOrBelowDiagOut;
}

-(double) propAtOrBelowDiagWeighted
{
	return propAtOrBelowDiagWeighted;
}

-(int) numCumPropAtOrBelowDiagWeighted
{
	return numCumPropAtOrBelowDiagWeighted;
}

-(int) behavior
{
	return behavior;
}

-(int) lagBehavior
{
	return lagBehavior;
}

-(int) changeBehavior
{
	return changeBehavior;
}

-(int) socLearningIn
{
	return socLearningIn;
}

// setters 
-(void) setLeftIntIn: (double) left_int_in
{
	leftIntIn = left_int_in;
}

-(void) setRightIntIn: (double) right_int_in
{
	rightIntIn = right_int_in;
}

-(void) setExpIn: (double) exponent_in
{
	expIn = exponent_in;
}

-(void) setLeftIntOut: (double) left_int_out
{
	leftIntOut = left_int_out;
}

-(void) setRightIntOut: (double) right_int_out
{
	rightIntOut = right_int_out;
}

-(void) setExpOut: (double) exponent_out
{
	expOut = exponent_out;
}

-(void) setWeightSocLearningIn: (double) wIn
{
	weightSocLearningIn = wIn;
}

-(void) setPropAtOrBelowDiagIn: (double) propAtOrBelowIn
{
	propAtOrBelowDiagIn = propAtOrBelowIn;
}

-(void) setPropAtOrBelowDiagOut: (double) propAtOrBelowOut
{
	propAtOrBelowDiagOut = propAtOrBelowOut;
}

-(void) setPropAtOrBelowDiagWeighted: (double) propAtOrBelowWeighted
{
	propAtOrBelowDiagWeighted = propAtOrBelowWeighted;
}

-(void) setNumCumPropAtOrBelowDiagWeighted: (int) numCumPropWeighted
{
	numCumPropAtOrBelowDiagWeighted = numCumPropWeighted;
}

-(void) setBehavior: (int) beh
{
	behavior = beh;
}

-(void) setLagBehavior: (int) lagBeh
{
	lagBehavior = lagBeh;
}

-(void) setChangeBehavior: (int) changeBeh
{
	changeBehavior = changeBeh;
}

-(void) setSocLearningIn: (int) socLearnIn
{
	socLearningIn = socLearnIn;
}

// procedural methods
-(void) calcPropAtOrBelowDiagIn // approx proportion of domain for in-group social learning function over which function is at or below 45-degree line
{
	int i = 0;
	int numSteps = 10000;
	
	propAtOrBelowDiagIn = 0.0;
	
	while ((double) i / (double) numSteps <= 1.0)
	{
		if ((leftIntIn + ((rightIntIn - leftIntIn) * pow((double) i / (double) numSteps,expIn) / (pow((double) i / (double) numSteps,expIn) + pow((double) 1.0 - (double) i / (double) numSteps,expIn)))) <= ((double) i / (double) numSteps))
		{
			propAtOrBelowDiagIn += (double) 1;
		}
		
		i++;
	}
	
	propAtOrBelowDiagIn /= ((double) numSteps + 1.0);
	
	if (propAtOrBelowDiagIn < 0.0)
	{
		propAtOrBelowDiagIn = 0.0;
	}
	
	if (propAtOrBelowDiagIn > 1.0)
	{
		propAtOrBelowDiagIn = 1.0;
	}
}

-(void) calcPropAtOrBelowDiagOut // approx proportion of domain for out-group social learning function over which function is at or below 45-degree line
{
	int i = 0;
	int numSteps = 10000;
	
	propAtOrBelowDiagOut = 0.0;
	
	while ((double) i / (double) numSteps <= 1.0)
	{
		if ((leftIntOut + ((rightIntOut - leftIntOut) * pow((double) i / (double) numSteps,expOut) / (pow((double) i / (double) numSteps,expOut) + pow((double) 1.0 - (double) i / (double) numSteps,expOut)))) <= ((double) i / (double) numSteps))
		{
			propAtOrBelowDiagOut += (double) 1;
		}
		
		i++;
	}
	
	propAtOrBelowDiagOut /= ((double) numSteps + 1.0);
	
	if (propAtOrBelowDiagOut < 0.0)
	{
		propAtOrBelowDiagOut = 0.0;
	}
	
	if (propAtOrBelowDiagOut > 1.0)
	{
		propAtOrBelowDiagOut = 1.0;
	}
}

-(void) calcPropAtOrBelowDiagWeighted // approx proportion of domain for weighted social learning function over which function is at or below 45-degree line
{
	int i = 0;
	int numSteps = 10000;
	
	propAtOrBelowDiagWeighted = 0.0;
	
	while ((double) i / (double) numSteps <= 1.0)
	{
		if (weightSocLearningIn * (leftIntIn + ((rightIntIn - leftIntIn) * pow((double) i / (double) numSteps,expIn) / (pow((double) i / (double) numSteps,expIn) + pow((double) 1.0 - (double) i / (double) numSteps,expIn)))) + (1.0 - weightSocLearningIn) * (leftIntOut + ((rightIntOut - leftIntOut) * pow((double) i / (double) numSteps,expOut) / (pow((double) i / (double) numSteps,expOut) + pow((double) 1.0 - (double) i / (double) numSteps,expOut)))) <= ((double) i / (double) numSteps))
		{
			propAtOrBelowDiagWeighted += (double) 1;
		}
		
		i++;
	}
	
	propAtOrBelowDiagWeighted /= ((double) numSteps + 1.0);
	
	if (propAtOrBelowDiagWeighted < 0.0)
	{
		propAtOrBelowDiagWeighted = 0.0;
	}
	
	if (propAtOrBelowDiagWeighted > 1.0)
	{
		propAtOrBelowDiagWeighted = 1.0;
	}
}

-(void) freqDepSocLearningWithIn: (double) freqBehOneIn andOut: (double) freqBehOneOut
{
	if (((double) 1.0 - genrand_real2()) <= weightSocLearningIn) // in-group soc learning
	{
		if (((double) 1.0 - genrand_real2()) <= (leftIntIn + ((rightIntIn - leftIntIn) * pow(freqBehOneIn,expIn) / (pow(freqBehOneIn,expIn) + pow((double) 1.0 - freqBehOneIn,expIn)))))
		{
			behavior = 1;
		}
		else
		{
			behavior = 0; 
		}
		
		socLearningIn = 1;
	}
	else // out-group soc learning
	{
		if (((double) 1.0 - genrand_real2()) <= (leftIntOut + ((rightIntOut - leftIntOut) * pow(freqBehOneOut,expOut) / (pow(freqBehOneOut,expOut) + pow((double) 1.0 - freqBehOneOut,expOut)))))
		{
			behavior = 1;
		}
		else
		{
			behavior = 0; 
		}
		
		socLearningIn = 0;
	}
}

@end